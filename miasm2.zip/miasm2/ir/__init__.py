"Intermediate representation methods"
