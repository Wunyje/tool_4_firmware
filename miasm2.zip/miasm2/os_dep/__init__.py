"Operating System specific methods"
